```markdown
# Author site — Elegant theme (static + PayFast)

What is included
- Static multi-page site: index.html, shop.html, about.html, contact.html, blog/post pages.
- Owner and follower demo login + client-side dashboard (localStorage-based).
- Shop items that start a PayFast payment flow via a serverless signing endpoint (example provided).
- Contact form integration using Formspree (replace endpoint).
- Mini game on Home page for visitor interaction.

Important placeholders to replace
- In contact.html: replace YOUR_FORMSPREE_ENDPOINT with your Formspree id.
- In contact.html: replace PHONE_NUMBER with your WhatsApp number (no +).
- In scripts/shop.js: replace PAYMENT_API_URL with your deployed serverless endpoint URL.
- In functions/payfast-create/index.js: set environment variables PAYFAST_URL, PAYFAST_MERCHANT_ID, PAYFAST_MERCHANT_KEY, (optional) PAYFAST_PASSPHRASE.

Quick local test
1. Save files in a folder with structure:
   - index.html, shop.html, contact.html, about.html, blog.html, post.html, owner-login.html, follower-login.html, owner-dashboard.html, shop-success.html, styles.css, README.md
   - /scripts: auth.js, posts.js, shop.js, game.js
   - /functions: payfast-create/index.js (for serverless deploy)
2. Run a static server:
   - `python -m http.server 8000`
   - Open http://localhost:8000

Deploy static site to GitHub Pages
- Create a repo, push files to main, then enable Pages -> main / root.

Deploy serverless PayFast function
- Use Vercel or Netlify Functions.
- Add env vars: PAYFAST_URL, PAYFAST_MERCHANT_ID, PAYFAST_MERCHANT_KEY, (optional) PAYFAST_PASSPHRASE.
- Deploy and copy the function URL to scripts/shop.js PAYMENT_API_URL.

Security & production notes
- The PayFast merchant key/passphrase must never be in client-side code — use serverless endpoint.
- Implement an IPN (notify) handler to verify payments and mark orders as complete. You can add email sending (SendGrid) or WhatsApp notifications (Twilio) from the notify handler.
- Replace demo localStorage auth with a real identity provider (Supabase, Firebase Auth, Netlify Identity) if you want secure admin access.

If you want, I can:
- Push these files to a GitHub repo for you (tell me the repo name).
- Deploy and adapt the serverless function for Vercel or Netlify and provide exact env var instructions.
- Swap the theme to "Playful" or "Minimal" instead — say which one.
```