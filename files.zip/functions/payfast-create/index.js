// Example serverless PayFast creation function (Node). Deploy to Vercel/Netlify/Render.
// IMPORTANT: set PAYFAST_URL, PAYFAST_MERCHANT_ID, PAYFAST_MERCHANT_KEY (and PASSPHRASE if used) as environment variables.
const crypto = require('crypto');

const PAYFAST_URL = process.env.PAYFAST_URL || 'https://sandbox.payfast.co.za/eng/process';
const MERCHANT_ID = process.env.PAYFAST_MERCHANT_ID || 'YOUR_MERCHANT_ID';
const MERCHANT_KEY = process.env.PAYFAST_MERCHANT_KEY || 'YOUR_MERCHANT_KEY';
const PASSPHRASE = process.env.PAYFAST_PASSPHRASE || ''; // if you have one

function generateSignature(params, passphrase) {
  // Build param string (sorted by key)
  const keys = Object.keys(params).sort();
  let str = keys.map(k => `${k}=${encodeURIComponent(params[k])}`).join('&');
  if (passphrase) str += `&passphrase=${encodeURIComponent(passphrase)}`;
  return crypto.createHash('md5').update(str).digest('hex');
}

function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

exports.handler = async function (event) {
  try {
    const body = JSON.parse(event.body || '{}');
    const { itemId, itemName, amount, return_url, cancel_url, notify_url } = body;

    const pfParams = {
      merchant_id: MERCHANT_ID,
      merchant_key: MERCHANT_KEY,
      return_url: return_url || 'https://your-site.example.com/shop-success.html',
      cancel_url: cancel_url || 'https://your-site.example.com/shop.html',
      notify_url: notify_url || '',
      m_payment_id: itemId || ('order-' + Date.now()),
      amount: Number(amount).toFixed(2),
      item_name: itemName || 'Order'
    };

    const signature = generateSignature(pfParams, PASSPHRASE);

    const formInputs = Object.keys(pfParams).map(k => {
      return `<input type="hidden" name="${k}" value="${escapeHtml(pfParams[k])}">`;
    }).join('\n') + `\n<input type="hidden" name="signature" value="${escapeHtml(signature)}">`;

    const htmlForm = `
      <form id="pfForm" action="${PAYFAST_URL}" method="post">
        ${formInputs}
      </form>
      <script>document.getElementById('pfForm').submit();</script>
    `;

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payfastForm: htmlForm })
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};