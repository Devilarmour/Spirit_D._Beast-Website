// Lightweight "Catch the Words" game
(function () {
  const canvas = document.getElementById('game-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  let running = false;
  let score = 0;
  const words = [];
  const wordList = ['poem','story','ink','verse','echo','page','dream','rhyme','voice','line','whisper'];

  function spawnWord() {
    const text = wordList[Math.floor(Math.random() * wordList.length)];
    const x = Math.random() * (width - 120) + 40;
    words.push({ text, x, y: -10, speed: 0.6 + Math.random() * 1.6, id: Date.now() + Math.random() });
  }

  function draw() {
    ctx.clearRect(0,0,width,height);
    ctx.fillStyle = '#111827';
    ctx.font = '18px Merriweather, Georgia, serif';
    words.forEach(w => {
      ctx.fillText(w.text, w.x, w.y);
    });
  }

  function step() {
    if (!running) return;
    if (Math.random() < 0.035) spawnWord();
    words.forEach(w => w.y += w.speed);
    for (let i = words.length - 1; i >= 0; i--) {
      if (words[i].y > height + 20) words.splice(i,1);
    }
    draw();
    requestAnimationFrame(step);
  }

  canvas.addEventListener('click', function (e) {
    const rect = canvas.getBoundingClientRect();
    const cx = (e.clientX - rect.left) * (canvas.width / rect.width);
    const cy = (e.clientY - rect.top) * (canvas.height / rect.height);
    ctx.font = '18px Merriweather, Georgia, serif';
    for (let i = words.length - 1; i >= 0; i--) {
      const w = words[i];
      const wWidth = ctx.measureText(w.text).width;
      const wx = w.x, wy = w.y - 14, wh = 18;
      if (cx >= wx && cx <= wx + wWidth && cy >= wy && cy <= wy + wh) {
        score += 1;
        words.splice(i,1);
        document.getElementById('score').textContent = 'Score: ' + score;
        return;
      }
    }
  });

  document.getElementById('start-game').addEventListener('click', function () {
    if (running) {
      running = false;
      this.textContent = 'Start';
    } else {
      running = true;
      score = 0;
      document.getElementById('score').textContent = 'Score: 0';
      this.textContent = 'Pause';
      step();
    }
  });
})();