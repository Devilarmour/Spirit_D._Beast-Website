// scripts/posts.js: client-side posts storage & renderer
(function (global) {
  const KEY = 'acme_posts_v2';

  function read() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) {
        const sample = [
          {
            id: 'welcome',
            title: 'Welcome to the blog',
            date: new Date().toISOString(),
            content: '<p>This is a sample post stored locally in your browser.</p>'
          }
        ];
        localStorage.setItem(KEY, JSON.stringify(sample));
        return sample;
      }
      return JSON.parse(raw);
    } catch (e) {
      return [];
    }
  }
  function write(posts) {
    localStorage.setItem(KEY, JSON.stringify(posts));
  }

  const Posts = {
    getAll() {
      return read().sort((a,b)=> new Date(b.date)-new Date(a.date));
    },
    getPostById(id) {
      return read().find(p => p.id === id);
    },
    createPost({ title, content }) {
      const posts = read();
      const id = title.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') + '-' + Date.now();
      const p = { id, title, date: new Date().toISOString(), content };
      posts.push(p);
      write(posts);
      return id;
    },
    deletePost(id) {
      const posts = read().filter(p => p.id !== id);
      write(posts);
    }
  };

  function renderList(containerId = 'posts-list') {
    const el = document.getElementById(containerId);
    if (!el) return;
    const posts = Posts.getAll();
    if (!posts.length) {
      el.innerHTML = '<p>No posts yet.</p>';
      return;
    }
    el.innerHTML = posts.map(p => `
      <article class="post-card" aria-labelledby="${p.id}-title">
        <h3 id="${p.id}-title">${p.title}</h3>
        <p class="meta">${new Date(p.date).toLocaleDateString()}</p>
        <p>${(p.content || '').replace(/(<([^>]+)>)/ig,'').slice(0,160)}…</p>
        <p><a class="btn small" href="post.html?id=${encodeURIComponent(p.id)}">Read</a></p>
      </article>
    `).join('');
  }

  global.Posts = Posts;
  document.addEventListener('DOMContentLoaded', function () {
    renderList('posts-list');
  });
})(window);