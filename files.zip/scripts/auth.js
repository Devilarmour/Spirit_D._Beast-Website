// scripts/auth.js (unchanged logic; demo only)
(function (global) {
  const STORAGE_KEY = 'acme_demo_v2';
  const DEFAULT = {
    role: '', // 'owner' | 'follower'
    ownerEmail: 'owner@example.com',
    ownerPassword: 'ownerpass',
    followers: []
  };

  function read() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT));
        return Object.assign({}, DEFAULT);
      }
      return Object.assign({}, DEFAULT, JSON.parse(raw));
    } catch (e) {
      return Object.assign({}, DEFAULT);
    }
  }

  function write(data) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (e) { /* ignore */ }
  }

  const Auth = {
    loginOwner(email, password) {
      const s = read();
      if (email.toLowerCase() === (s.ownerEmail || '').toLowerCase() && password === (s.ownerPassword || '')) {
        s.role = 'owner';
        write(s);
        return true;
      }
      return false;
    },
    isOwner() {
      const s = read();
      return s.role === 'owner';
    },
    signOut() {
      const s = read();
      s.role = '';
      write(s);
    },
    addFollower(email) {
      if (!email) return;
      const s = read();
      const e = email.toLowerCase();
      if (!s.followers.includes(e)) s.followers.push(e);
      s.role = 'follower';
      write(s);
    },
    getFollowers() {
      const s = read();
      return s.followers || [];
    }
  };

  global.Auth = Auth;
})(window);