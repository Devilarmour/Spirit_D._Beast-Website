// scripts/shop.js - client-side shop action; calls serverless endpoint to create signed PayFast form
(function () {
  const PAYMENT_API_URL = 'https://YOUR_SERVERLESS_ENDPOINT.example.com/create-payfast'; // <-- REPLACE with your deployed function

  function init() {
    document.querySelectorAll('.buy-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        const item = JSON.parse(this.getAttribute('data-item'));
        startPurchase(item);
      });
    });
  }

  async function startPurchase(item) {
    try {
      const payload = {
        itemId: item.id,
        itemName: item.name,
        amount: item.amount,
        return_url: location.origin + '/shop-success.html',
        cancel_url: location.origin + '/shop.html',
        notify_url: '' // optional: your notify endpoint
      };

      const res = await fetch(PAYMENT_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('Payment initialization failed.');
      const data = await res.json();

      if (data.redirectUrl) {
        window.location = data.redirectUrl;
        return;
      }
      if (data.payfastForm) {
        const div = document.createElement('div');
        div.innerHTML = data.payfastForm;
        document.body.appendChild(div);
        const form = div.querySelector('form');
        if (form) form.submit();
        return;
      }

      alert('Unexpected response from payment server. Check console.');
      console.error(data);
    } catch (err) {
      console.error(err);
      alert('Unable to start payment. See console for details.');
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();